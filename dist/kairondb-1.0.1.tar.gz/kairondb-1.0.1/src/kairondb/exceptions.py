class ValidationError(Exception):
    """Exceção levantada para erros de validação nos campos do modelo."""
    pass